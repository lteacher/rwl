﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RobotInitial.LynxProtocol.Enums {
    //copied to the model for the time being
    //enum LynxIRPort {
    //    FRONT,
    //    FRONTLEFT,
    //    REARLEFT,
    //    FRONTRIGHT,
    //    REARRIGHT,
    //    REAR
    //}
}
