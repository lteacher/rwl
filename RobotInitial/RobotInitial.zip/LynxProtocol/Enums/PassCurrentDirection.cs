﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RobotInitial.LynxProtocol {
    enum PassCurrentDirection : byte {
        STOPPED = 0,
        FORWARD = 1,
        REVERSE = 2
    }
}
